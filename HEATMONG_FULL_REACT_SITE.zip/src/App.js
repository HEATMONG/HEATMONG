
import React from "react";

function App() {
  return (
    <div className="App">
      <header>
        <h1>$HEATMONG</h1>
        <p>Too Horny to Die • Born from WW3 • Powered by Ferret Heat</p>
      </header>

      <section className="intro">
        <h2>🔥 The Lore</h2>
        <p>
          After World War 3 scorched the Earth, one creature remained: a radioactive, overcooked, terminally online ferret. 
          $HEATMONG isn't a revolution — it's a meltdown. Welcome to the post-nuclear meme economy.
        </p>
      </section>

      <section className="tokenomics">
        <h2>💰 Tokenomics</h2>
        <ul>
          <li><strong>Blockchain:</strong> Solana</li>
          <li><strong>Total Supply:</strong> 6,969,696,969</li>
          <li><strong>Tax:</strong> 1% (for meme warfare & promotion)</li>
          <li><strong>Tax Wallet:</strong> AAcdfH9QfoNxPamuna7MSwZoBix62VCphzSAs2qrU7rb</li>
        </ul>
      </section>

      <section className="allocation">
        <h2>📦 Allocation</h2>
        <p>
          100% of supply goes into Pump.fun. No presale. No VC. No mercy.
        </p>
      </section>

      <section className="roadmap">
        <h2>🗺️ Roadmap</h2>
        <ul>
          <li>Q1: Launch, memes hotter than nukes</li>
          <li>Q2: Telegram raids & unholy Twitter ops</li>
          <li>Q3: Merch? Breed-to-earn? Who knows</li>
          <li>Q4: Heat death of the universe</li>
        </ul>
      </section>

      <section className="manifesto">
        <h2>🔥 Manifesto</h2>
        <p>
          You didn’t ask for this coin. We didn’t ask for this world.<br />
          But if we’re going to burn — we might as well be feral.<br /><br />
          Join the last meme standing.<br />
          Join the heat.<br />
          <strong>$HEATMONG</strong>
        </p>
      </section>

      <section className="links">
        <h2>🌐 Links</h2>
        <ul>
          <li><a href="https://pump.fun" target="_blank" rel="noopener noreferrer">Launch on Pump.fun</a></li>
          <li><a href="https://t.me/heatmong" target="_blank" rel="noopener noreferrer">Join the Bunker (Telegram)</a></li>
          <li><a href="#">Twitter (coming soon)</a></li>
        </ul>
      </section>

      <footer>
        &copy; 2025 $HEATMONG. Created in the ashes of WW3.
      </footer>
    </div>
  );
}

export default App;
