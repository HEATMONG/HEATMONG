
# $HEATMONG React Website

🔥 Too Horny to Die. Born from WW3. Powered by Ferret Heat.

## How to Use

1. Extract this ZIP.
2. Open the folder in VS Code or any code editor.
3. Make sure you have Node.js installed.
4. Run these commands:

```bash
npm install
npm start
```

The site will open at `http://localhost:3000`

## Deployment

You can deploy this to:
- Vercel (recommended)
- Netlify
- GitHub Pages

## Assets

- `public/heatmong.png`: The $HEATMONG ferret mascot
